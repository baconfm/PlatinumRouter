window.addEventListener("DOMContentLoaded", () => {
  const map = document.getElementById("map");
  const svg = document.getElementById("lines");
  const container = document.getElementById("mapContainer");
  const selectionBox = document.getElementById("selectionBox");

  const toggleEditorBtn = document.getElementById("toggleEditorBtn");
  const addPointBtn = document.getElementById("addPointBtn");
  const deleteSelectedBtn = document.getElementById("deleteSelectedBtn");
  const clearSelectionBtn = document.getElementById("clearSelectionBtn");
  const exportBtn = document.getElementById("exportBtn");

  const saveMarkerBtn = document.getElementById("saveMarkerBtn");
  const deleteMarkerBtn = document.getElementById("deleteMarkerBtn");

  const pointCountEl = document.getElementById("pointCount");
  const selectedCountEl = document.getElementById("selectedCount");
  const filtersBar = document.getElementById("filtersBar");
  const filterSearch = document.getElementById("filterSearch");

  const editorPanel = document.getElementById("editorPanel");
  const defaultTypeInput = document.getElementById("defaultTypeInput");
  const defaultLabelInput = document.getElementById("defaultLabelInput");
  const exportOutput = document.getElementById("exportOutput");

  init();

  function init() {
    loadPoints();

    window.AppMap.init(map, svg, container);

    if (window.AppPoints?.init) {
      window.AppPoints.init(map);
    }

    if (window.AppEditor?.init) {
      window.AppEditor.init();
    }

    if (window.AppSelection?.init) {
      window.AppSelection.init(map, container, selectionBox);
    }

    window.AppFilters.renderFilterControls(filtersBar, filterSearch);

    bindEvents();
    rerender();
  }

  function loadPoints() {
    const rawPoints = Array.isArray(window.MAP_POINTS) ? window.MAP_POINTS : [];

    window.AppState.points = rawPoints
      .map(window.AppUtils.normalizePoint)
      .filter(Boolean);

    window.AppState.visibleTypes = new Set(
      [...new Set(window.AppState.points.map((p) => p.type))].sort()
    );
  }

  function bindEvents() {
    toggleEditorBtn.addEventListener("click", () => {
      window.AppEditor.toggleEditorMode(toggleEditorBtn, editorPanel, addPointBtn);
      rerender();
    });

    addPointBtn.addEventListener("click", () => {
      window.AppEditor.toggleAddPointMode(addPointBtn);
    });

    deleteSelectedBtn.addEventListener("click", () => {
      window.AppEditor.deleteSelectedPoints();
      window.AppFilters.renderFilterControls(filtersBar, filterSearch);
      rerender();
    });

    clearSelectionBtn.addEventListener("click", () => {
      window.AppSelection.clearSelection();
      window.AppState.activeMarkerId = null;
      window.AppEditor.clearMarkerForm();
      rerender();
    });

    exportBtn.addEventListener("click", () => {
      window.AppExport.exportDataJs(exportOutput);
    });

    if (saveMarkerBtn) {
      saveMarkerBtn.addEventListener("click", () => {
        window.AppEditor.saveActiveMarker();
        window.AppFilters.renderFilterControls(filtersBar, filterSearch);
        rerender();
      });
    }

    if (deleteMarkerBtn) {
      deleteMarkerBtn.addEventListener("click", () => {
        window.AppEditor.deleteActiveMarker();
        window.AppFilters.renderFilterControls(filtersBar, filterSearch);
        rerender();
      });
    }

    filterSearch.addEventListener("input", () => {
      window.AppFilters.renderFilterControls(filtersBar, filterSearch);
    });

    container.addEventListener("mousedown", onMouseDown);
    container.addEventListener("mousemove", onMouseMove);
    container.addEventListener("click", onClick);

    window.addEventListener("mouseup", onMouseUp);

    window.addEventListener("keydown", (event) => {
      const state = window.AppState;

      if (event.key === "Delete" && state.editorMode) {
        window.AppEditor.deleteSelectedPoints();
        window.AppFilters.renderFilterControls(filtersBar, filterSearch);
        rerender();
      }

      if (event.key === "Escape" && state.editorMode) {
        state.addPointMode = false;
        addPointBtn.classList.remove("active");
        window.AppSelection.clearSelection();
        state.activeMarkerId = null;
        window.AppEditor.clearMarkerForm();
        rerender();
      }
    });
  }

  function onMouseDown(event) {
    const state = window.AppState;
    const pointEl = event.target.closest(".point");

    if (state.editorMode && pointEl) {
      const pointId = pointEl.dataset.id;

      if (!state.selectedIds.has(pointId)) {
        if (!event.shiftKey) {
          state.selectedIds.clear();
        }
        state.selectedIds.add(pointId);
      }

      state.activeMarkerId = pointId;
      window.AppEditor.setActiveMarker(pointId);
      window.AppSelection.beginSelectionDrag(event);
      rerender();
      return;
    }

    if (state.editorMode && !pointEl) {
      if (event.shiftKey) {
        window.AppSelection.beginBoxSelection(event, true);
        rerender();
        return;
      }

      window.AppMap.startPan(event.clientX, event.clientY);
      return;
    }

    if (!state.editorMode) {
      window.AppMap.startPan(event.clientX, event.clientY);
    }
  }

  function onMouseMove(event) {
    const state = window.AppState;

    if (state.isDraggingSelection) {
      window.AppSelection.updateSelectionDrag(event);

      if (state.activeMarkerId) {
        const point = state.points.find((p) => p.id === state.activeMarkerId);
        if (point) {
          window.AppEditor.loadMarkerIntoForm(point);
        }
      }

      rerenderPointsOnly();
      return;
    }

    if (state.isBoxSelecting) {
      window.AppSelection.updateBoxSelection(event);
      rerenderPointsOnly();
      return;
    }

    if (state.isDraggingMap) {
      window.AppMap.movePan(event.clientX, event.clientY);
    }
  }

  function onMouseUp() {
    const state = window.AppState;

    if (state.isDraggingSelection) {
      window.AppSelection.endSelectionDrag();
    }

    if (state.isBoxSelecting) {
      window.AppSelection.endBoxSelection();
    }

    if (state.isDraggingMap) {
      window.AppMap.endPan();
    }

    rerender();
  }

  function onClick(event) {
    const state = window.AppState;
    const pointEl = event.target.closest(".point");

    if (state.editorMode && pointEl) {
      const pointId = pointEl.dataset.id;

      if (event.shiftKey) {
        window.AppSelection.togglePointSelection(pointId);
      } else {
        state.selectedIds.clear();
        state.selectedIds.add(pointId);
      }

      state.activeMarkerId = pointId;
      window.AppEditor.setActiveMarker(pointId);
      rerender();
      return;
    }

    if (state.editorMode && state.addPointMode && !pointEl) {
      window.AppEditor.addPointAtClick(
        event,
        container,
        defaultTypeInput,
        defaultLabelInput
      );

      state.addPointMode = false;
      addPointBtn.classList.remove("active");

      window.AppFilters.renderFilterControls(filtersBar, filterSearch);
      rerender();
    }
  }

  function rerender() {
    window.AppPoints.renderPoints(map);

    if (window.AppLines?.renderLines) {
      window.AppLines.renderLines(svg);
    }

    window.AppPoints.updateCounts(pointCountEl, selectedCountEl);
    window.AppMap.updateTransform();
  }

  function rerenderPointsOnly() {
    window.AppPoints.renderPoints(map);

    if (window.AppLines?.renderLines) {
      window.AppLines.renderLines(svg);
    }

    window.AppPoints.updateCounts(pointCountEl, selectedCountEl);
    window.AppMap.updateTransform();
  }

  window.rerender = rerender;
});