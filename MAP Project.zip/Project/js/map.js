window.AppMap = {
  init(mapEl, svgEl, containerEl) {
    this.mapEl = mapEl;
    this.svgEl = svgEl;
    this.containerEl = containerEl;

    this.buildBaseMap();
    this.fitToScreen();
    this.applyTransform();
    this.bindEvents();
  },

  buildBaseMap() {
    const { MAP_SIZE, TILE_SIZE, GRID_SIZE } = window.AppConfig;

    this.mapEl.innerHTML = "";

    this.mapEl.style.width = `${MAP_SIZE}px`;
    this.mapEl.style.height = `${MAP_SIZE}px`;
    this.mapEl.style.position = "absolute";
    this.mapEl.style.left = "0";
    this.mapEl.style.top = "0";
    this.mapEl.style.transformOrigin = "top left";

    this.svgEl.innerHTML = "";
    this.svgEl.setAttribute("width", MAP_SIZE);
    this.svgEl.setAttribute("height", MAP_SIZE);
    this.svgEl.style.position = "absolute";
    this.svgEl.style.left = "0";
    this.svgEl.style.top = "0";
    this.svgEl.style.transformOrigin = "top left";
    this.svgEl.style.pointerEvents = "none";
    this.svgEl.id = this.svgEl.id || "map-lines";

    for (let y = 0; y < GRID_SIZE; y += 1) {
      for (let x = 0; x < GRID_SIZE; x += 1) {
        const tile = document.createElement("div");
        tile.className = "tile";
        tile.style.position = "absolute";
        tile.style.width = `${TILE_SIZE}px`;
        tile.style.height = `${TILE_SIZE}px`;
        tile.style.left = `${x * TILE_SIZE}px`;
        tile.style.top = `${y * TILE_SIZE}px`;
        tile.style.backgroundImage = `url(https://tiles.guides4gamers.com/sites/22/maps/98-4/slices/2/${x}x${y}.jpg)`;
        tile.style.backgroundSize = "cover";
        tile.style.backgroundRepeat = "no-repeat";
        this.mapEl.appendChild(tile);
      }
    }
  },

  fitToScreen() {
    const state = window.AppState;
    const { MAP_SIZE } = window.AppConfig;

    const containerWidth = this.containerEl.clientWidth;
    const containerHeight = this.containerEl.clientHeight;

    if (!containerWidth || !containerHeight) return;

    const scaleX = containerWidth / MAP_SIZE;
    const scaleY = containerHeight / MAP_SIZE;

    state.scale = Math.min(scaleX, scaleY);
    state.offsetX = (containerWidth - MAP_SIZE * state.scale) / 2;
    state.offsetY = (containerHeight - MAP_SIZE * state.scale) / 2;
  },

  applyTransform() {
    const state = window.AppState;
    const transform = `translate(${state.offsetX}px, ${state.offsetY}px) scale(${state.scale})`;

    this.mapEl.style.transform = transform;
    this.svgEl.style.transform = transform;
  },

  updateTransform() {
    this.applyTransform();
  },

  zoomAt(clientX, clientY, deltaY) {
    const state = window.AppState;
    const rect = this.containerEl.getBoundingClientRect();

    const mouseX = clientX - rect.left;
    const mouseY = clientY - rect.top;

    const worldX = (mouseX - state.offsetX) / state.scale;
    const worldY = (mouseY - state.offsetY) / state.scale;

    const zoomFactor = deltaY < 0 ? 1.1 : 0.9;
    state.scale *= zoomFactor;
    state.scale = Math.max(0.2, Math.min(state.scale, 8));

    state.offsetX = mouseX - worldX * state.scale;
    state.offsetY = mouseY - worldY * state.scale;

    this.applyTransform();
  },

  startPan(clientX, clientY) {
    const state = window.AppState;
    state.isDraggingMap = true;
    state.dragStartX = clientX - state.offsetX;
    state.dragStartY = clientY - state.offsetY;

    if (this.containerEl) {
      this.containerEl.style.cursor = "grabbing";
    }
  },

  movePan(clientX, clientY) {
    const state = window.AppState;
    if (!state.isDraggingMap) return;

    state.offsetX = clientX - state.dragStartX;
    state.offsetY = clientY - state.dragStartY;

    this.applyTransform();
  },

  endPan() {
    const state = window.AppState;
    state.isDraggingMap = false;

    if (this.containerEl) {
      this.containerEl.style.cursor = "grab";
    }
  },

  bindEvents() {
    window.addEventListener("resize", () => {
      this.fitToScreen();
      this.applyTransform();
      if (window.rerender) {
        window.rerender();
      }
    });

    this.containerEl.addEventListener(
      "wheel",
      (event) => {
        event.preventDefault();
        this.zoomAt(event.clientX, event.clientY, event.deltaY);

        if (window.AppLines && this.svgEl) {
          window.AppLines.renderLines(this.svgEl);
        }
      },
      { passive: false }
    );
  }
};