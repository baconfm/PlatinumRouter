window.AppExport = {
  exportDataJs(exportOutputEl) {
    const state = window.AppState;

    const cleaned = state.points
      .map((point) => {
        const out = {
          id: point.id,
          x: +Number(point.x).toFixed(6),
          y: +Number(point.y).toFixed(6),
          type: point.type
        };

        if (point.label && point.label.trim()) {
          out.label = point.label.trim();
        }

        if (point.questId && point.questId.trim()) {
          out.questId = point.questId.trim();
        }

        if (point.availability && point.availability.trim()) {
          out.availability = point.availability.trim();
        }

        if (point.missionEnd) {
          out.missionEnd = true;
        }

        return out;
      })
      .sort((a, b) => {
        if (a.type !== b.type) {
          return a.type.localeCompare(b.type);
        }
        return a.id.localeCompare(b.id);
      });

    const text = `window.MAP_POINTS = ${JSON.stringify(cleaned, null, 2)};`;

    if (exportOutputEl) {
      exportOutputEl.value = text;
      exportOutputEl.focus();
      exportOutputEl.select();
    }

    return text;
  }
};