window.AppSelection = {
  init(mapEl, containerEl, selectionBoxEl) {
    this.mapEl = mapEl;
    this.containerEl = containerEl;
    this.selectionBoxEl = selectionBoxEl;
  },

  // =========================
  // POINT SELECTION
  // =========================

  togglePointSelection(id) {
    const state = window.AppState;

    if (state.selectedIds.has(id)) {
      state.selectedIds.delete(id);
    } else {
      state.selectedIds.add(id);
    }
  },

  clearSelection() {
    window.AppState.selectedIds.clear();
  },

  // =========================
  // DRAG SELECTED POINTS
  // =========================

  beginSelectionDrag(event) {
    const state = window.AppState;

    if (state.selectedIds.size === 0) return;

    state.isDraggingSelection = true;

    const rect = this.containerEl.getBoundingClientRect();

    state.dragStartMouseX = event.clientX;
    state.dragStartMouseY = event.clientY;

    // store original positions
    state.dragStartPositions = {};

    state.selectedIds.forEach((id) => {
      const p = state.points.find((pt) => pt.id === id);
      if (p) {
        state.dragStartPositions[id] = { x: p.x, y: p.y };
      }
    });
  },

  updateSelectionDrag(event) {
    const state = window.AppState;
    if (!state.isDraggingSelection) return;

    const dx = event.clientX - state.dragStartMouseX;
    const dy = event.clientY - state.dragStartMouseY;

    const { MAP_SIZE } = window.AppConfig;

    // convert screen delta → world delta
    const worldDX = dx / state.scale / MAP_SIZE;
    const worldDY = dy / state.scale / MAP_SIZE;

    state.selectedIds.forEach((id) => {
      const p = state.points.find((pt) => pt.id === id);
      const start = state.dragStartPositions[id];

      if (p && start) {
        p.x = start.x + worldDX;
        p.y = start.y + worldDY;
      }
    });
  },

  endSelectionDrag() {
    window.AppState.isDraggingSelection = false;
  },

  // =========================
  // BOX SELECTION
  // =========================

  beginBoxSelection(event, keepExisting = false) {
    const state = window.AppState;

    state.isBoxSelecting = true;

    if (!keepExisting) {
      state.selectedIds.clear();
    }

    const rect = this.containerEl.getBoundingClientRect();

    state.boxStartX = event.clientX - rect.left;
    state.boxStartY = event.clientY - rect.top;

    this.selectionBoxEl.style.display = "block";
  },

  updateBoxSelection(event) {
    const state = window.AppState;
    if (!state.isBoxSelecting) return;

    const rect = this.containerEl.getBoundingClientRect();

    const currentX = event.clientX - rect.left;
    const currentY = event.clientY - rect.top;

    const x = Math.min(state.boxStartX, currentX);
    const y = Math.min(state.boxStartY, currentY);
    const w = Math.abs(state.boxStartX - currentX);
    const h = Math.abs(state.boxStartY - currentY);

    // draw box
    this.selectionBoxEl.style.left = `${x}px`;
    this.selectionBoxEl.style.top = `${y}px`;
    this.selectionBoxEl.style.width = `${w}px`;
    this.selectionBoxEl.style.height = `${h}px`;

    this.updateBoxSelectionPoints(x, y, w, h);
  },

  updateBoxSelectionPoints(x, y, w, h) {
    const state = window.AppState;
    const { MAP_SIZE } = window.AppConfig;

    state.selectedIds.clear();

    const left = x;
    const right = x + w;
    const top = y;
    const bottom = y + h;

    state.points.forEach((p) => {
      // convert world → screen
      const screenX = p.x * MAP_SIZE * state.scale + state.offsetX;
      const screenY = p.y * MAP_SIZE * state.scale + state.offsetY;

      if (
        screenX >= left &&
        screenX <= right &&
        screenY >= top &&
        screenY <= bottom
      ) {
        state.selectedIds.add(p.id);
      }
    });
  },

  endBoxSelection() {
    const state = window.AppState;

    state.isBoxSelecting = false;
    this.selectionBoxEl.style.display = "none";
  }
};