window.AppPoints = {
  init(mapEl) {
    this.mapEl = mapEl;
  },

  renderPoints(mapEl) {
    const state = window.AppState;
    const { MAP_SIZE } = window.AppConfig;

    if (!mapEl) return;

    mapEl.querySelectorAll(".point, .point-label").forEach((el) => el.remove());

    state.points.forEach((point) => {
      if (state.visibleTypes && !state.visibleTypes.has(point.type)) {
        return;
      }

      const el = document.createElement("div");
      el.className = "point";
      el.dataset.id = point.id;
      el.dataset.type = point.type;

      el.style.position = "absolute";
      el.style.left = `${point.x * MAP_SIZE}px`;
      el.style.top = `${point.y * MAP_SIZE}px`;
      el.style.transform = "translate(-50%, -50%)";
      el.style.pointerEvents = "auto";
      el.style.cursor = "pointer";
      el.style.boxSizing = "border-box";
      el.style.zIndex = "20";

      this.applyBaseStyle(el, point);
      this.applyQuestStyle(el, point);
      this.applySelectionStyle(el, point);

      if (point.label) {
        const label = document.createElement("div");
        label.className = "point-label";
        label.textContent = this.getLabelText(point);

        label.style.position = "absolute";
        label.style.left = "50%";
        label.style.top = "18px";
        label.style.transform = "translateX(-50%)";
        label.style.fontSize = "10px";
        label.style.lineHeight = "1.1";
        label.style.whiteSpace = "nowrap";
        label.style.color = "#fff";
        label.style.textShadow = "0 1px 2px #000";
        label.style.pointerEvents = "none";
        label.style.userSelect = "none";

        el.appendChild(label);
      }

      mapEl.appendChild(el);
    });
  },

  applyBaseStyle(el, point) {
    el.style.width = "16px";
    el.style.height = "16px";
    el.style.background = this.getColor(point);
    el.style.border = "2px solid #000";
    el.style.borderRadius = "50%";
    el.style.opacity = "1";
    el.style.boxShadow = "none";

    if (point.type === "quest_start") {
      el.style.borderRadius = "2px";
      el.style.transform = "translate(-50%, -50%) rotate(45deg)";
      el.style.width = "18px";
      el.style.height = "18px";
    }
  },

  applyQuestStyle(el, point) {
    const availability = point.availability || "";

    if (availability === "blocked") {
      el.style.opacity = "0.45";
      el.style.filter = "grayscale(0.25)";
      el.style.border = "2px solid #ff5252";
    }

    if (availability === "optional") {
      el.style.border = "2px dashed #ffd54f";
      el.style.boxShadow = "0 0 0 2px rgba(255, 213, 79, 0.25)";
    }

    if (availability === "allowed") {
      el.style.boxShadow = "0 0 0 2px rgba(0, 230, 118, 0.25)";
    }

    if (point.missionEnd) {
      const existing = el.style.boxShadow ? `${el.style.boxShadow}, ` : "";
      el.style.boxShadow = `${existing}0 0 0 3px #ff00aa inset`;
    }
  },

  applySelectionStyle(el, point) {
    const state = window.AppState;

    if (state.selectedIds.has(point.id)) {
      el.style.outline = "3px solid #fff";
      el.style.zIndex = "30";
    }

    if (state.activeMarkerId === point.id) {
      el.style.outline = "3px solid yellow";
      el.style.zIndex = "40";
    }
  },

  getLabelText(point) {
    let text = point.label || point.type;

    if (point.type === "quest_start") {
      text = `START: ${text}`;
    }

    if (point.missionEnd) {
      text += " [END]";
    }

    if (point.availability === "blocked") {
      text += " [BLOCKED]";
    }

    if (point.availability === "optional") {
      text += " [OPTIONAL]";
    }

    return text;
  },

  updateCounts(pointCountEl, selectedCountEl) {
    const state = window.AppState;

    if (pointCountEl) {
      pointCountEl.textContent = state.points.length;
    }

    if (selectedCountEl) {
      selectedCountEl.textContent = state.selectedIds.size;
    }
  },

  getColor(point) {
    const COLORS = {
      altar: "#ff7a3d",
      artifact: "#a34cff",
      bamboo: "#ffd43b",
      camp: "#ff6b4a",
      cricket: "#c7d93d",
      farm: "#8fd14f",
      fox_den: "#ff9f1a",
      haiku: "#25c7f0",
      hotspring: "#46c96b",
      lighthouse: "#d9d9d9",
      main_tale: "#ff4b4b",
      mythic: "#ff2f92",
      outpost: "#ff4fa3",
      poi: "#9e9e9e",
      quest: "#ffc61a",
      quest_start: "#00e0ff",
      record: "#58d06f",
      shinto: "#35a7ff",
      side_tale: "#19e6a7",
      start: "#00ff7f",
      temple: "#7f8c8d",
      town: "#a98b7d"
    };

    return COLORS[point.type] || "#888888";
  }
};