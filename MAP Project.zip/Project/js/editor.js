window.AppEditor = {
  init() {
    this.selectedPoint = null;

    this.idInput = document.getElementById("editIdInput");
    this.typeInput = document.getElementById("editTypeInput");
    this.labelInput = document.getElementById("editLabelInput");
    this.questIdInput = document.getElementById("editQuestIdInput");
    this.availabilityInput = document.getElementById("editAvailabilityInput");
    this.xInput = document.getElementById("editXInput");
    this.yInput = document.getElementById("editYInput");
    this.missionEndInput = document.getElementById("editMissionEndInput");

    this.saveBtn = document.getElementById("saveMarkerBtn");
    this.deleteBtn = document.getElementById("deleteMarkerBtn");

    if (this.saveBtn) {
      this.saveBtn.onclick = () => this.saveActiveMarker();
    }

    if (this.deleteBtn) {
      this.deleteBtn.onclick = () => this.deleteActiveMarker();
    }
  },

  toggleEditorMode(toggleEditorBtn, editorPanelEl, addPointBtn) {
    const state = window.AppState;

    state.editorMode = !state.editorMode;

    if (toggleEditorBtn) {
      toggleEditorBtn.textContent = `Editor: ${state.editorMode ? "On" : "Off"}`;
      toggleEditorBtn.classList.toggle("active", state.editorMode);
    }

    if (editorPanelEl) {
      editorPanelEl.classList.toggle("hidden", !state.editorMode);
    }

    if (!state.editorMode) {
      state.addPointMode = false;
      state.activeMarkerId = null;
      state.selectedIds.clear();

      if (addPointBtn) {
        addPointBtn.classList.remove("active");
      }

      this.selectedPoint = null;
      this.clearMarkerForm();
    }
  },

  toggleAddPointMode(addPointBtn) {
    const state = window.AppState;
    if (!state.editorMode) return;

    state.addPointMode = !state.addPointMode;

    if (addPointBtn) {
      addPointBtn.classList.toggle("active", state.addPointMode);
    }
  },

  addPointAtClick(event, containerEl, defaultTypeInput, defaultLabelInput) {
    const state = window.AppState;
    const { screenToWorld, worldToNormalized } = window.AppUtils;

    const world = screenToWorld(event.clientX, event.clientY, containerEl);
    const normalized = worldToNormalized(world);

    const point = {
      id: `manual-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      x: normalized.x,
      y: normalized.y,
      type: (defaultTypeInput?.value || "poi").trim() || "poi",
      label: (defaultLabelInput?.value || "").trim(),
      missionEnd: false
    };

    state.points.push(point);
    state.visibleTypes.add(point.type);

    state.activeMarkerId = point.id;
    state.selectedIds.clear();
    state.selectedIds.add(point.id);

    this.setActiveMarker(point.id);
  },

  setActiveMarker(markerId) {
    const state = window.AppState;
    state.activeMarkerId = markerId || null;

    const point = state.points.find((p) => p.id === markerId);
    if (!point) {
      this.selectedPoint = null;
      this.clearMarkerForm();
      return;
    }

    this.selectedPoint = point;
    this.loadMarkerIntoForm(point);
  },

  loadMarkerIntoForm(point) {
    if (!point) {
      this.clearMarkerForm();
      return;
    }

    if (this.idInput) this.idInput.value = point.id || "";
    if (this.typeInput) this.typeInput.value = point.type || "";
    if (this.labelInput) this.labelInput.value = point.label || "";
    if (this.questIdInput) this.questIdInput.value = point.questId || "";
    if (this.availabilityInput) this.availabilityInput.value = point.availability || "";
    if (this.xInput) this.xInput.value = Number(point.x).toFixed(6);
    if (this.yInput) this.yInput.value = Number(point.y).toFixed(6);
    if (this.missionEndInput) this.missionEndInput.checked = Boolean(point.missionEnd);
  },

  clearMarkerForm() {
    if (this.idInput) this.idInput.value = "";
    if (this.typeInput) this.typeInput.value = "";
    if (this.labelInput) this.labelInput.value = "";
    if (this.questIdInput) this.questIdInput.value = "";
    if (this.availabilityInput) this.availabilityInput.value = "";
    if (this.xInput) this.xInput.value = "";
    if (this.yInput) this.yInput.value = "";
    if (this.missionEndInput) this.missionEndInput.checked = false;
  },

  saveActiveMarker() {
    const state = window.AppState;
    if (!state.activeMarkerId) return;

    const point = state.points.find((p) => p.id === state.activeMarkerId);
    if (!point) return;

    point.type = (this.typeInput?.value || "poi").trim() || "poi";
    point.label = (this.labelInput?.value || "").trim();
    point.x = window.AppUtils.clamp(parseFloat(this.xInput?.value), 0, 1);
    point.y = window.AppUtils.clamp(parseFloat(this.yInput?.value), 0, 1);
    point.missionEnd = Boolean(this.missionEndInput?.checked);

    const questId = (this.questIdInput?.value || "").trim();
    if (questId) {
      point.questId = questId;
    } else {
      delete point.questId;
    }

    const availability = (this.availabilityInput?.value || "").trim();
    if (availability) {
      point.availability = availability;
    } else {
      delete point.availability;
    }

    state.visibleTypes.add(point.type);
    this.selectedPoint = point;

    if (window.rerender) {
      window.rerender();
    }
  },

  deleteActiveMarker() {
    const state = window.AppState;
    if (!state.activeMarkerId) return;

    const activeId = state.activeMarkerId;

    state.points = state.points.filter((p) => p.id !== activeId);
    state.selectedIds.delete(activeId);
    state.activeMarkerId = null;

    this.selectedPoint = null;
    this.clearMarkerForm();

    if (window.rerender) {
      window.rerender();
    }
  },

  deleteSelectedPoints() {
    const state = window.AppState;
    if (state.selectedIds.size === 0) return;

    const selected = new Set(state.selectedIds);

    state.points = state.points.filter((p) => !selected.has(p.id));

    if (state.activeMarkerId && selected.has(state.activeMarkerId)) {
      state.activeMarkerId = null;
      this.selectedPoint = null;
      this.clearMarkerForm();
    }

    state.selectedIds.clear();
  }
};