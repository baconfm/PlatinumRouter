window.AppFilters = {
  renderFilterControls(filtersBarEl, filterSearchEl) {
    const state = window.AppState;
    const { TYPE_COLORS } = window.AppConfig;

    const searchValue = filterSearchEl.value.trim().toLowerCase();
    const allTypes = [...new Set(state.points.map((p) => p.type))].sort();

    filtersBarEl.innerHTML = "";

    allTypes
      .filter((type) => type.toLowerCase().includes(searchValue))
      .forEach((type) => {
        const label = document.createElement("label");
        label.className = "filter-item";

        const input = document.createElement("input");
        input.type = "checkbox";
        input.checked = state.visibleTypes.has(type);

        input.addEventListener("change", () => {
          if (input.checked) {
            state.visibleTypes.add(type);
          } else {
            state.visibleTypes.delete(type);
          }

          window.AppPoints.applyPointVisibility();
        });

        const colorDot = document.createElement("span");
        colorDot.style.display = "inline-block";
        colorDot.style.width = "10px";
        colorDot.style.height = "10px";
        colorDot.style.borderRadius = "50%";
        colorDot.style.background = TYPE_COLORS[type] || TYPE_COLORS.unknown;

        const text = document.createElement("span");
        text.textContent = type;

        label.appendChild(input);
        label.appendChild(colorDot);
        label.appendChild(text);
        filtersBarEl.appendChild(label);
      });
  }
};