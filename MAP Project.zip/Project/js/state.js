window.AppState = {
  scale: 1,
  offsetX: 0,
  offsetY: 0,

  isDraggingMap: false,
  dragStartX: 0,
  dragStartY: 0,

  isBoxSelecting: false,
  boxStartX: 0,
  boxStartY: 0,

  isDraggingSelection: false,
  dragSelectionStartWorld: null,
  dragSelectionOriginalPositions: new Map(),

  editorMode: false,
  addPointMode: false,

  points: [],
  visibleTypes: new Set(),
  selectedIds: new Set(),

  activeMarkerId: null
};