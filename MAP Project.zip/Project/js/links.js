window.AppLinks = {
  init(svgEl) {
    this.svgEl = svgEl;
  },

  renderQuestLinks() {
    const state = window.AppState;
    const { MAP_SIZE } = window.AppConfig;
    const svgEl = this.svgEl;

    if (!svgEl) return;

    svgEl.innerHTML = "";

    const grouped = new Map();

    state.points.forEach((point) => {
      if (!point.linkId) return;

      if (!grouped.has(point.linkId)) {
        grouped.set(point.linkId, []);
      }

      grouped.get(point.linkId).push(point);
    });

    grouped.forEach((points) => {
      if (points.length < 2) return;

      const start =
        points.find((p) => p.linkRole === "start") || points[0];
      const end =
        points.find((p) => p.linkRole === "end") || points[1];

      if (!start || !end) return;
      if (!state.visibleTypes.has(start.type) || !state.visibleTypes.has(end.type)) return;

      const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
      line.setAttribute("x1", start.x * MAP_SIZE);
      line.setAttribute("y1", start.y * MAP_SIZE);
      line.setAttribute("x2", end.x * MAP_SIZE);
      line.setAttribute("y2", end.y * MAP_SIZE);
      line.setAttribute("class", "quest-link-line");

      svgEl.appendChild(line);
    });
  }
};