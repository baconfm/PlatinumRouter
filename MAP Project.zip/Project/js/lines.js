window.AppLines = {
  renderLines(svgEl) {
    const state = window.AppState;
    const { MAP_SIZE } = window.AppConfig;

    if (!svgEl) return;

    svgEl.innerHTML = "";

    const groups = new Map();

    // Group all quest-linked points
    state.points.forEach((point) => {
      if (!point.questId) return;

      if (!groups.has(point.questId)) {
        groups.set(point.questId, []);
      }

      groups.get(point.questId).push(point);
    });

    groups.forEach((points, questId) => {
      const start = points.find((p) => p.type === "quest_start");
      if (!start) return;

      // End markers
      const missionEnds = points.filter((p) => p.missionEnd);

      // Other linked markers
      const linked = points.filter(
        (p) => p.id !== start.id && !p.missionEnd
      );

      // Draw to normal linked markers
      linked.forEach((point) => {
        this.drawLine(svgEl, start, point, MAP_SIZE, {
          stroke: this.getAvailabilityColor(point.availability),
          width: 2,
          dash: this.getAvailabilityDash(point.availability),
          opacity: this.getAvailabilityOpacity(point.availability)
        });
      });

      // Draw to mission end markers
      missionEnds.forEach((point) => {
        this.drawLine(svgEl, start, point, MAP_SIZE, {
          stroke: "#ff00aa",
          width: 3,
          dash: "10 6",
          opacity: 0.95
        });
      });
    });
  },

  drawLine(svgEl, a, b, mapSize, style) {
    const line = document.createElementNS("http://www.w3.org/2000/svg", "line");

    line.setAttribute("x1", a.x * mapSize);
    line.setAttribute("y1", a.y * mapSize);
    line.setAttribute("x2", b.x * mapSize);
    line.setAttribute("y2", b.y * mapSize);

    line.setAttribute("stroke", style.stroke || "#00e0ff");
    line.setAttribute("stroke-width", style.width || 2);
    line.setAttribute("opacity", style.opacity ?? 0.85);

    if (style.dash) {
      line.setAttribute("stroke-dasharray", style.dash);
    }

    line.setAttribute("pointer-events", "none");

    svgEl.appendChild(line);
  },

  getAvailabilityColor(availability) {
    switch (availability) {
      case "allowed":
        return "#00e676";
      case "blocked":
        return "#ff5252";
      case "optional":
        return "#ffd54f";
      default:
        return "#00e0ff";
    }
  },

  getAvailabilityDash(availability) {
    switch (availability) {
      case "allowed":
        return "";
      case "blocked":
        return "4 6";
      case "optional":
        return "10 6";
      default:
        return "";
    }
  },

  getAvailabilityOpacity(availability) {
    switch (availability) {
      case "allowed":
        return 0.95;
      case "blocked":
        return 0.7;
      case "optional":
        return 0.85;
      default:
        return 0.8;
    }
  }
};