function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function normalizePoint(point) {
  if (!point || typeof point.x !== "number" || typeof point.y !== "number") {
    return null;
  }

  const normalized = {
    id: point.id || `manual-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    x: clamp(point.x, 0, 1),
    y: clamp(point.y, 0, 1),
    type: point.type || "poi",
    label: point.label || "",
    missionEnd: Boolean(point.missionEnd)
  };

  if (point.questId && String(point.questId).trim()) {
    normalized.questId = String(point.questId).trim();
  }

  if (point.availability && String(point.availability).trim()) {
    normalized.availability = String(point.availability).trim();
  }

  return normalized;
}

function screenToWorld(clientX, clientY, container) {
  const state = window.AppState;
  const rect = container.getBoundingClientRect();
  const screenX = clientX - rect.left;
  const screenY = clientY - rect.top;

  return {
    x: (screenX - state.offsetX) / state.scale,
    y: (screenY - state.offsetY) / state.scale
  };
}

function worldToNormalized(world) {
  const { MAP_SIZE } = window.AppConfig;

  return {
    x: clamp(world.x / MAP_SIZE, 0, 1),
    y: clamp(world.y / MAP_SIZE, 0, 1)
  };
}

window.AppUtils = {
  clamp,
  normalizePoint,
  screenToWorld,
  worldToNormalized
};