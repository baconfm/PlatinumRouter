window.AppConfig = {
  TILE_SIZE: 512,
  GRID_SIZE: 4,
  MAP_SIZE: 512 * 4,

  TYPE_COLORS: {
    altar: "#ff7a3d",
    artifact: "#a34cff",
    bamboo: "#ffd43b",
    camp: "#ff6b4a",
    cricket: "#c7d93d",
    farm: "#8fd14f",
    fox_den: "#ff9f1a",
    haiku: "#25c7f0",
    hotspring: "#46c96b",
    lighthouse: "#d9d9d9",
    main_tale: "#ff4b4b",
    mythic: "#ff2f92",
    outpost: "#ff4fa3",
    poi: "#9e9e9e",
    quest: "#ffc61a",
    quest_start: "#00e0ff",
    record: "#58d06f",
    shinto: "#35a7ff",
    side_tale: "#19e6a7",
    start: "#00ff7f",
    temple: "#7f8c8d",
    town: "#a98b7d",
    unknown: "#888888"
  }
};